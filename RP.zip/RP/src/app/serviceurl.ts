export class serviceURL {	
   // public prodURL : string = "https://reportit.hexaware.com/Report/Api/";
   // public prodURL : string = "http://172.25.164.72:8056/Api/";
    //  public prodURL : string = "https://reportit.hexaware.com/reportitapiv2/Api/";    
    public prodURL : string = "https://reportit.hexaware.com/reportitapiv2/Api/"; 
}