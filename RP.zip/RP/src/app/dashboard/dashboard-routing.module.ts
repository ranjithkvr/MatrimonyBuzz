import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { DashboardComponent } from './dashboard.component';
import { UsecasesComponent } from './usecases/usecases.component';

const adminRoutes: Routes = [ 
  {
    path: '',
    component: DashboardComponent, 
    children: [
      {
        path: '',
        children: [
          { path : 'usecases', component : UsecasesComponent },
               ]
      }
    ]
  }
];


@NgModule({
  imports: [
 RouterModule.forChild(adminRoutes)    
  ],
  declarations: [],
  exports: [
    RouterModule
  ]
})
export class DashboardRoutingModule { }
