import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { serviceURL } from '../../serviceURL';
import * as $ from "jquery";

@Component({
  selector: 'app-artuseractivities',
  templateUrl: './artuseractivities.component.html',
  styleUrls: ['./artuseractivities.component.scss']
})
export class ArtuseractivitiesComponent implements OnInit {

  GetARTDetails : any = [];
   chg_pass_GetARTDetailsPassCount : string = "...";
   chg_pass_Mobile_user : string = "...";
   chg_pass_Destop_user : string = "...";
   chg_pass_Internet_user : string = "...";
   chg_pass_Intranet_user : string = "...";


                       frg_pass_GetARTDetailsPassCount : string = "...";
                       frg_pass_Mobile_user : string = "...";
                       frg_pass_Destop_user : string = "...";
                       frg_pass_Internet_user : string = "...";
                       frg_pass_Intranet_user : string = "...";


                       unl_pass_GetARTDetailsPassCount : string = "...";
                       unl_pass_Mobile_user : string = "...";
                       unl_pass_Destop_user : string = "...";
                       unl_pass_Internet_user : string = "...";
                       unl_pass_Intranet_user : string = "...";

  constructor(private httpService : HttpClient, public url : serviceURL) { }



__GetARTDetails(){

      this.httpService.get(this.url.prodURL+'GetARTDetails').subscribe(
             data => {
                    this.GetARTDetails =  data as any [];
               
                     if(data[0].useractivity === 'CHANGE_PASSWORD'){
                        
                       this.chg_pass_GetARTDetailsPassCount =  data[0].Count;
                       this.chg_pass_Mobile_user = data[0].ismobiledeviceYesCnt ;
                       this.chg_pass_Destop_user =  data[0].ismobiledeviceNoCnt ;
                       this.chg_pass_Internet_user = data[0].isinternetYesCnt ;
                       this.chg_pass_Intranet_user = data[0].isinternetNoCnt ;
                   } 



                     if(data[1].useractivity === 'Forgot_Password'){
                        
                       this.frg_pass_GetARTDetailsPassCount =  data[1].Count;
                       this.frg_pass_Mobile_user = data[1].ismobiledeviceYesCnt ;
                       this.frg_pass_Destop_user =  data[1].ismobiledeviceNoCnt ;
                       this.frg_pass_Internet_user = data[1].isinternetYesCnt ;
                       this.frg_pass_Intranet_user = data[1].isinternetNoCnt ;
                   } 



                    if(data[2].useractivity === 'Unlock_Account'){
                        
                       this.unl_pass_GetARTDetailsPassCount =  data[2].Count;
                       this.unl_pass_Mobile_user = data[2].ismobiledeviceYesCnt ;
                       this.unl_pass_Destop_user =  data[2].ismobiledeviceNoCnt ;
                       this.unl_pass_Internet_user = data[2].isinternetYesCnt ;
                       this.unl_pass_Intranet_user = data[2].isinternetNoCnt ;
                   } 
                       
                   },
             (err: HttpErrorResponse) => {
              console.log(err.message);
             }
      );
   
}



  ngOnInit() {

 // this.__GetARTDetails();

  }

}
