import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { serviceURL } from '../../serviceURL';

import { sidebarService } from '../../sidebar.service';
import { Title } from '@angular/platform-browser';

import * as $ from "jquery";
declare var $: $

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
   providers : [
    serviceURL, sidebarService
  ]
})
export class CustomersComponent implements OnInit {

   customerID: any;

   constructor(private router : Router, private httpService: HttpClient,  private activatedRoute: ActivatedRoute,  private location: Location,  public url : serviceURL, public titleService : Title) { 

          this.customerID = (this.activatedRoute.snapshot.params).id;
          this.customerID == undefined ?  this.customerID = 0 : 
          this.customerID = (this.activatedRoute.snapshot.params).id;
            let totalCount : any; 

        $.getJSON(this.url.prodURL + 'GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;  
             
             $("#automated_Tkt_count").html(totalCount);
        })

   }

  myCustomers: string [];
  selected = null;		

  ngOnInit () {

    this.titleService.setTitle("Report IT Dashboard - customers");
     
    this.httpService.get( this.url.prodURL + 'GetCustomerDetails').subscribe(
      data => {
        this.myCustomers = data as string [];	// FILL THE ARRAY WITH DATA.

      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }


}
