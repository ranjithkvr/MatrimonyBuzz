import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { serviceURL } from '../serviceURL';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';
import { Title } from '@angular/platform-browser';

import * as $ from "jquery";
declare var $: $
declare var session: any; 
declare var userSession: any; 


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {


  customerID: any;
 

  constructor( private router : Router, private httpService: HttpClient,    public url : serviceURL, private activatedRoute: ActivatedRoute,  private location: Location, public titleService : Title) {

   let totalCount : any; 

          this.customerID = (this.activatedRoute.snapshot.params).id;
          this.customerID == undefined ?  this.customerID = 0 :  this.customerID = (this.activatedRoute.snapshot.params).id;
        

$.getJSON(this.url.prodURL + 'GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;  
             
             $("#automated_Tkt_count").html(totalCount);
        })



  let userSession = {
    checkUserSession: function(){
        if($.session.get("isValidUser") == "Y")
            {
                return true;
            }
        else
            {
                return false;
            }
    },
    removeUserSession : function(){
        //debugger;
        $.session.remove("isValidUser");
        this.router.navigate(['/home'])
    }
}  

      let isValidUser =  userSession.checkUserSession();
             if(!isValidUser)
             {

               
                this.router.navigate(['/home'])
                
             }


  }

  ngOnInit() {




  }

}
