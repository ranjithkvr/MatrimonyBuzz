import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';

import { serviceURL } from '../../serviceURL';

import * as $ from "jquery";
import * as echarts from 'echarts';

declare var Circles: any;
declare var multiselect: any;

@Component({
  selector: 'app-customerview',
  templateUrl: './customerview.component.html',
  styleUrls: ['./customerview.component.scss'],
   providers : [
    serviceURL
  ]
})
export class CustomerviewComponent implements OnInit {

    customerID: any;
    customerByName : any = [];
  
  constructor(private httpService: HttpClient, private router: Router, private activatedRoute: ActivatedRoute,  private location: Location, public url : serviceURL) {

       this.customerID = (this.activatedRoute.snapshot.params).id;

    }

       __BindAAIInfo() {       
     
        $.getJSON( this.url.prodURL + "Report/Api/GetCustomerWiseAAI/" + this.customerID, function(data) {

            $("#AAIRequssseCaseProd").html(data.ReleasedCnt);
               $("#AAIRequssseCaseDev").html(data.InProgressCnt);            
            
        })
    };



  ngOnInit() {

  var  url = this.url.prodURL;

  this.__BindAAIInfo();


  $('#customerlist option[value="' + this.customerID + '"]').attr("selected","selected"); 
       

    var customerDashboard = {

    defaults:{
        customerId: this.customerID
    },
    init:function(){
        customerDashboard.bindIncidentUseCase();
        customerDashboard.bindMonthWiseTicketAnalysis();
      //customerDashboard.bindUseCase();
        customerDashboard.bindAutomationStatistics();
    },
    bindIncidentUseCase: function() {     

        $.getJSON( url + "Report/Api/GetCustomerUseCaseDetails/" + customerDashboard.defaults.customerId, function(data) {

            var useCaseCnt = 0;
            var incidentCnt = 0;
            var serviceReqCnt = 0;
            //console.log(data)
            //debugger
            if( data != null  && data != undefined && data.UseCaseProduction != null && data.UseCaseProduction != undefined)
            {
                var filterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Incident'})
                if(filterjson != null && filterjson != undefined && filterjson.length > 0)
                {
                    useCaseCnt += filterjson[0].Count;
                    incidentCnt = filterjson[0].Count;
                    $("#hincidentUseCaseProd").html(filterjson[0].Count);
                    $("#spnIncCnt").html(filterjson[0].Count);
                }
                var srfilterjson = customerDashboard.find_in_object(data.UseCaseProduction, {RequestType: 'Service Request'})
                if(srfilterjson != null && srfilterjson != undefined &&srfilterjson.length>0 )
                {
                    useCaseCnt += srfilterjson[0].Count;
                    serviceReqCnt = srfilterjson[0].Count;
                    $("#hServiceRequseCaseProd").html(srfilterjson[0].Count);
                    $("#spnServiceReqCnt").html(srfilterjson[0].Count);
                }
                
                var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100);
                // argument error -- var incSuccessRate = Math.round((incidentCnt / useCaseCnt) * 100,0);
                
                var myCircle = Circles.create({
                  id:                  'circles-1',
                  radius:              60,
                  value:               incSuccessRate,
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['#EBE9E9', '#E28811'],
                  duration:            400,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });
                
                var serviceReqSuccessRate = Math.round((serviceReqCnt / useCaseCnt) * 100);
                // argument error --  Math.round((serviceReqCnt / useCaseCnt) * 100,0);

                
                var myCircle = Circles.create({
                  id:                  'circles-2',
                  radius:              60,
                  value:               serviceReqSuccessRate,
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['#EBE9E9', '#E28811'],
                  duration:            400,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });
                
                $("#spnautomationUSCnt").html(useCaseCnt);
            }
            if( data != null  && data != undefined && data.UseCaseDevelopment != null && data.UseCaseDevelopment != undefined)
            {
                 var filterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hincidentUseCaseDev").html(filterjson[0].Count);
                }
                
                var srfilterjson = customerDashboard.find_in_object(data.UseCaseDevelopment, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseDev").html(srfilterjson[0].Count);
                }
            }
            if( data != null  && data != undefined && data.UseCaseAnalysis != null && data.UseCaseAnalysis != undefined)
            {
                 var filterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Incident'})
                 if(filterjson != null&& filterjson != undefined&& filterjson.length > 0)
                {
                    $("#hIncidentUseCaseAna").html(filterjson[0].Count);
                }
                
                var srfilterjson = customerDashboard.find_in_object(data.UseCaseAnalysis, {RequestType: 'Service Request'})
                if(srfilterjson != null&& srfilterjson != undefined &&srfilterjson.length>0)
                {
                    $("#hServiceRequseCaseAnal").html(srfilterjson[0].Count);
                }
            }
            
            //self.customers(data);
            
        })
    },
    bindMonthWiseTicketAnalysis: function(){
      
        $.getJSON( url + "Report/Api/GetCustomerMonthYrWiseTicketAnalysis/" + customerDashboard.defaults.customerId, function(data) {

            console.log(data)

            //debugger;
            
            if(data.length > 0 )
            {
            var htmlTabContent = "";
            htmlTabContent += '<table class="table table-hover  table-striped">'
            htmlTabContent += '<thead>'
            htmlTabContent += '<tr cl>'
            htmlTabContent += '<th scope="col" class="border-top-0">Month</th>'
            htmlTabContent += '<th scope="col" class="border-top-0">Total Tickets</th>'
            htmlTabContent += '<th scope="col" class="border-top-0">Automated Tickets</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">Success Rate</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">Rejected Tickets</th>'
            htmlTabContent+= '<th scope="col" class="border-top-0">Rejection Rate</th>'
            
            htmlTabContent+= '</tr>'
            htmlTabContent += '</thead>'
            htmlTabContent+= '<tbody>'
            
            for(var i = 0 ; i<data.length;i++)
            {
                htmlTabContent+= '<tr>'
                htmlTabContent+= '<td>'+data[i].Month+'</td>'
                htmlTabContent+= '<td>'+data[i].Count+'</td>'
                
                htmlTabContent+= '<td>'+data[i].AutomatedTickets+'</td>'
                htmlTabContent+= '<td>'+Math.round(data[i].SuccessRate)+' %</td>'
                //  htmlTabContent+= '<td>'+Math.round(data[i].SuccessRate,4)+' %</td>'
                htmlTabContent+= '<td>'+data[i].RejectedTickets+'</td>'
                htmlTabContent+= '<td>'+Math.round(data[i].RejectedRate)+' %</td>'
                //    htmlTabContent+= '<td>'+Math.round(data[i].RejectedRate,4)+' %</td>'
                htmlTabContent+= '</tr>'

            }
            
                                   
            htmlTabContent+= '</tbody>'
            htmlTabContent+= '</table>'
            
            console.log(htmlTabContent)
            $("#dvCustomerMonthTktAna").html(htmlTabContent);
        }
        })
    },
    find_in_object: function (my_object, my_criteria) {
        return my_object.filter(function (obj) {
            return Object.keys(my_criteria).every(function (c) {
                return obj[c] == my_criteria[c];
            });
        });
    },
    bindUseCase: function()
    {
        $.getJSON( url + "Report/Api/GetCustomerUseCaseWise/" + customerDashboard.defaults.customerId, function(data) {
             console.log(data)
           // debugger;
            var useCaseTemplate = $("#dvUseCaseTemplate").html();
            $("#dvUseCaseContainer").html('');
            var category = []

            for(var i = 0;i<data.length;i++)
            {
                $("#dvUseCaseContainer").append(useCaseTemplate.replace(/{index}/g,i) ) 
                
                if($.inArray(data[i].ParentCategory+'('+data[i].ChildCategory+')',category) == -1)
                {
                    category.push(data[i].ParentCategory+'('+data[i].ChildCategory+')');
                }

                var tags = "";
                var tagArray = data[i].Tags.split(',');
                for(var j = 0;j< tagArray.length;j++)
                {
                    tags += '<h2 class="d-inline"> <span class="badge badge-secondary">';
                    tags += '<img src="../assets/images/incident_icn.svg" alt="" class="img-fluid" width="20px">'
                    tags += ''+tagArray[j]+'</span></h2>'
                }
                
                $("#dvUseCaseTags_"+i).html(tags);
                $("#dvUseCase_"+i).attr('data-parentCat',data[i].ParentCategory);
                $("#dvUseCase_"+i).attr('data-childCat',data[i].ChildCategory);

                $("#spnUseCaseName_"+i).html(data[i].UseCaseName);
                $("#hUseCaseDescription_"+i).html(data[i].Description);
                $("#hUseCaseManualMTTR_"+i).html(Math.round(data[i].ManualMTTR),0);
                $("#hUseCaseAutoMTTR_"+i).html(Math.round( data[i].AutomationMTTR),0);
                
                var successRatePer = Math.round(data[i].SuccessRate);
                //   var successRatePer = Math.round(data[i].SuccessRate,0);

                var colour = 'white'
                if(successRatePer >= 0 && successRatePer < 50)
                {
                    $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                    $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                    $("#dvSuccessRateContainer-"+i).addClass("bg-red");
                    colour = '#f7bf44'
                }
                else if(successRatePer > 50 && successRatePer < 80)
                    {
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-green");
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                        $("#dvSuccessRateContainer-"+i).addClass("bg-orange");
                        colour = '#ff9e6d'
                    }
                else
                    {
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-orange");
                        $("#dvSuccessRateContainer-"+i).removeClass("bg-red");
                        $("#dvSuccessRateContainer-"+i).addClass("bg-green");
                        colour = '#56e6c3'
                    }
                
		 var reqTags = data[i].RequestType;
                 
                 $("#RequestType_"+i+ " span").addClass(reqTags);
                 $("#RequestType_"+i+ " span").html(reqTags);

                 $('#circles-successrate-'+i).html(successRatePer + "%");
                   $("#totalCount_"+i).html(data[i].Count);
                /*
                 $("#totalCount_"+i).html(data[i].Count);
                
                 var myCircle = Circles.create({
                  id:                  'circles-successrate-'+i,
                  radius:              40,
                  value:               successRatePer,
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['', colour],
                  duration:            400,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });
                */
                var effReducedPer = 100 - ((data[i].AutomationMTTR * 100) / data[i].ManualMTTR)
                
                 var myCircle = Circles.create({
                  id:                  'circles-effreduced-'+i,
                  radius:              40,
                  value:               Math.round(effReducedPer), // Math.round(effReducedPer,0)
                  maxValue:            100,
                  width:               2,
                  text:                function(value){return value + '%';},
                  colors:              ['', '#56e6c3'],
                  duration:            400,
                  wrpClass:            'circles-wrp',
                  textClass:           'circles-text',
                  valueStrokeClass:    'circles-valueStroke',
                  maxValueStrokeClass: 'circles-maxValueStroke',
                  styleWrapper:        true,
                  styleText:           true
                });

            }

            customerDashboard.BuildCategoryMultiselect(category)
            
        })
    },
    bindAutomationStatistics: function(){
        
        $.getJSON( url + "Report/Api/GetCustomerMonthYrWiseTicketAnalysis/" + customerDashboard.defaults.customerId, function(data) {
            
            console.log(data)
            var monthArry = [];
            var automationTkts = [];
            var rejectedTkts = [];
            
           for(var i = 0;i<data.length;i++)
            {
                monthArry.push(data[i].Month);
                automationTkts.push(data[i].AutomatedTickets);
                rejectedTkts.push(data[i].RejectedTickets);
            }
            
            var dom = document.getElementById("container");
        var myChart = echarts.init(dom,'light');
        var app = {};
        var option = null;
        option = {    
            tooltip : {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross',
                    label: {
                        backgroundColor: '#6a7985'
                    }
                }
            },
            legend: {
                data:['Automated Ticket','Rejected Ticket']
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    boundaryGap : false,
                    data : monthArry
                }
            ],
            yAxis : [
                {
                    type : 'value'
                }
            ],
            series : [
                {
                    name:'Automated Ticket',
                    type:'line',
                    //smooth:true,
                    areaStyle: {normal: {}},
                    data:automationTkts
                },
                {
                    name:'Rejected Ticket',
                    type:'line',
                    //smooth:true,
                    areaStyle: {normal: {}},
                    data:rejectedTkts
                }

            ]
        };
        ;
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
        })
        
        
    },
    BuildCategoryMultiselect: function(category)
    {
        var content = ""
        content += '<optgroup label="Category">';
        for(var i=0; i < category.length;i++)
        {
            content += '<option value="'+category[i]+'">'+category[i]+'</option>';
        }
         content += '</optgroup>';

        $("#option-droup-demo").append(content);
       // $("#option-droup-demo").multiselect('rebuild');

      
    },
    filterByCategory: function(option,checked)
    {
        
        var selectedValue = $('select#option-droup-demo').val();
        
        $("#dvUseCaseContainer div.section-wrape").each(function(i){
            $(this).hide();               
        })
        
        for(var i = 0;i< selectedValue.length;i++)
        {
            //debugger
            var parentCategory = selectedValue[i].split('(')[0]
            var childCategory = selectedValue[i].split('(')[1].replace(')','')
            
              $("#dvUseCaseContainer div.section-wrape").each(function(i){
              
                if($(this).attr('data-parentCat').toLowerCase() == parentCategory.toLowerCase() && $(this).attr('data-childCat').toLowerCase() == childCategory.toLowerCase())
                {
                    $(this).show();
                }
            })
        }
        
        if(selectedValue.length == 0)
        {
             $("#dvUseCaseContainer div.section-wrape").each(function(i){
                $(this).show();               
            })
        }
    }
}


    customerDashboard.init();
    
  }



}
