import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { serviceURL } from '../../serviceURL';

import { sidebarService } from '../../sidebar.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.scss'],
   providers : [
    serviceURL, sidebarService
  ]
})
export class CustomersComponent implements OnInit {

   constructor( private httpService : HttpClient,  public url : serviceURL,  public sidebarnav: sidebarService ) { }

  myCustomers: string [];
  selected = null;		

  ngOnInit () {
     
    this.httpService.get( this.url.prodURL + 'Report/Api/GetCustomerDetails').subscribe(
      data => {
        this.myCustomers = data as string [];	// FILL THE ARRAY WITH DATA.

      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }


}
