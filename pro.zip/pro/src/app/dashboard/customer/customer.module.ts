import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BrowserModule } from '@angular/platform-browser';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { CustomerComponent } from './customer.component';



@NgModule({
  imports: [
    CommonModule,
    NgModule,
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  declarations: [ 
   CustomerComponent
  ]
})
export class CustomerModule {

 
 }
