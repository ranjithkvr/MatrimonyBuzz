import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http/src/response';
import { serviceURL } from '../../serviceURL';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';


import * as $ from "jquery";
declare var $: $
declare var session: any; 
declare var userSession: any; 


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  customerID: any;
 

  constructor (private router : Router, private httpService: HttpClient,    public url : serviceURL, private activatedRoute: ActivatedRoute,  private location: Location) { 

            let totalCount : any; 

          this.customerID = (this.activatedRoute.snapshot.params).id;
          this.customerID == undefined ?  this.customerID = 0 :  this.customerID = (this.activatedRoute.snapshot.params).id;      
         


        $.getJSON(this.url.prodURL + 'Report/Api/GetAutomatedTicketCount/' + this.customerID , function(data) {
             totalCount = data.Total;  
             
             $("#automated_Tkt_count").html(totalCount);
        })

       
          


    /*  this.httpService.get( this.url.prodURL + 'Report/Api/GetAutomatedTicketCount/' + this.customerID  ).subscribe(
          data => { 
 console.log("-----------------------------------");
console.log( data as any []);
console.log(this.totalCount = data.Total);
console.log("-------------- ****** ---------------------");
      //    this.count = data as string []; // FILL THE ARRAY WITH DATA.
          },
          (err: HttpErrorResponse) => {
            console.log (err.message);
          }
          ); */
  
       
    }


  ngOnInit () {
             
    
         }

    removeUserSession(){
           $.session.remove("isValidUser");
           this.router.navigate(["/home"]);
       }

}
